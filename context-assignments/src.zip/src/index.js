import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import {AppcontextProvider } from "./context/Appcontextprovider"

ReactDOM.render(
  <AppcontextProvider>
  <React.StrictMode>
    <App />
  </React.StrictMode>
  </AppcontextProvider>,
  document.getElementById('root')
);

reportWebVitals();
