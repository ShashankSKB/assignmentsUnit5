import logo from './logo.svg';
import './App.css';

import { Forms } from './components/forms';

function App() {
  return (
    <div className="App">
    <Forms/>
    </div>
  );
}

export default App;
